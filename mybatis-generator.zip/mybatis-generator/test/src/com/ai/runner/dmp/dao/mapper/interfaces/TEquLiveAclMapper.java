package com.ai.runner.dmp.dao.mapper.interfaces;

import com.ai.runner.dmp.dao.mapper.bo.TEquLiveAcl;
import com.ai.runner.dmp.dao.mapper.bo.TEquLiveAclCriteria;
import java.util.List;
import org.apache.ibatis.annotations.Param;

public interface TEquLiveAclMapper {
    int countByExample(TEquLiveAclCriteria example);

    int deleteByExample(TEquLiveAclCriteria example);

    int insert(TEquLiveAcl record);

    int insertSelective(TEquLiveAcl record);

    List<TEquLiveAcl> selectByExample(TEquLiveAclCriteria example);

    int updateByExampleSelective(@Param("record") TEquLiveAcl record, @Param("example") TEquLiveAclCriteria example);

    int updateByExample(@Param("record") TEquLiveAcl record, @Param("example") TEquLiveAclCriteria example);
}