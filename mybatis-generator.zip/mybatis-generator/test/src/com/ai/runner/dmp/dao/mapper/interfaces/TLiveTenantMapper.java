package com.ai.runner.dmp.dao.mapper.interfaces;

import com.ai.runner.dmp.dao.mapper.bo.TLiveTenant;
import com.ai.runner.dmp.dao.mapper.bo.TLiveTenantCriteria;
import java.util.List;
import org.apache.ibatis.annotations.Param;

public interface TLiveTenantMapper {
    int countByExample(TLiveTenantCriteria example);

    int deleteByExample(TLiveTenantCriteria example);

    int deleteByPrimaryKey(String id);

    int insert(TLiveTenant record);

    int insertSelective(TLiveTenant record);

    List<TLiveTenant> selectByExample(TLiveTenantCriteria example);

    TLiveTenant selectByPrimaryKey(String id);

    int updateByExampleSelective(@Param("record") TLiveTenant record, @Param("example") TLiveTenantCriteria example);

    int updateByExample(@Param("record") TLiveTenant record, @Param("example") TLiveTenantCriteria example);

    int updateByPrimaryKeySelective(TLiveTenant record);

    int updateByPrimaryKey(TLiveTenant record);
}